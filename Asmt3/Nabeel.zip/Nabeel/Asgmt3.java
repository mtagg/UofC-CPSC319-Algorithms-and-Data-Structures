


class Asgmt3 {
	public static void main(String[] args) {
		String file = AdjacencyMatrixParser.file_name();
		String inputFileName = file + ".txt";
		int[][] matrix = AdjacencyMatrixParser.parseFile(inputFileName); 
		DijkstrasAlgorithm.dijkstra(matrix, 0, file +  "_dijkstra_output.txt");

	}

}