CPSC 319 L01 - Summer2020
ASsignment # 3
Readme.txt



     
       Program prompts for a user input file name
       The file is assumed to contain an adacency matrix
       AdjacencyMatrixParser.parseFile will remove all lines starting with '#' symbol 
       The remaing matrix is split line by line by empty space and the string
       integers are converted to type integer, then fill up a int[n][n] array to send to 
       Dijkstras Algorithm.
     
       The output file uses the functions already present in FileIO.java
       along with modified versions of printsolution and printpath.
       DijkstrasAlgorithm.java is modified at the end of the class functions
       to assemble the data that is normally printed and save it to a string
       then send it to FileIO.writeFile() with the properly formated filename.
     

