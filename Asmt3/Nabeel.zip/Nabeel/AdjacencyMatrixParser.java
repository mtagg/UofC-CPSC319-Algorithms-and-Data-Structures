

import java.io.InputStreamReader;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;

public class AdjacencyMatrixParser {
     
	public static String file_name(){
          try{
               System.out.println("\n\nEnter a file name without '.txt'.  ");
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			return input.readLine();
          }catch(IOException e){e.printStackTrace(); System.out.println("Input file invalid");}
		return null;
	}



	public static int[][] parseFile(String file){
     
		List <String> lines = FileIO.readFile(file); 

          int  n = lines.size();
		String tmp; 
		int leng; 
          char temp;
          int i,j,k;
		for (i=0; i<n; i++){
               temp = lines.get(i).charAt(0);
			if (temp == '#'){
                    lines.remove(i);
                    i--;
                    n--;}
          }
          n = lines.size(); //adjacency matrix dimensions
          int[][] matrix = new int[n][n];
          i = 0;
		while (i<n){

               leng = lines.get(i).length();
               j = 0;k = 0;

			while (j < leng){//break to new line when end of line is reached at any stage
				tmp = "";
                    while (j < leng && lines.get(i).charAt(j) == ' ')
                    {
                         j++;
                    }
                    while (j < leng && lines.get(i).charAt(j) != ' ')
                    { 
                         tmp += lines.get(i).charAt(j);
                         j++;
                    }
                    matrix[i][k] = Integer.parseInt(tmp);//convert string number into type int	
                    k++;
                    
               }
               i++;
          }

          return matrix;
	}

}